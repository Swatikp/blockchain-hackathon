This is the backend services for Tree Felling in spring-boot.

To build the project , run command : mvn clean install

To run the REST services, run the command : mvn spring-boot:run

The swagger UI will be available at http://localhost:8081/swagger-ui.html

The relevant chaincode is kept in chaincode folder in this project.

This code was submitted by Gagan Vasudev, Swati, Dharmesh Khandelwal and Ajit Singh during bengaluru tech summit blockchain hackathon.