/*
 * Mindtree Ltd.
 */

package com.mindtree.TreeFelling.dto;

/**
 * @author SWATI RAJ
 *
 */
public class ChaincodeNameDto {
	
	private String chaincodeName;

	public String getChaincodeName() {
		return chaincodeName;
	}

	public void setChaincodeName(String chaincodeName) {
		this.chaincodeName = chaincodeName;
	}

}
