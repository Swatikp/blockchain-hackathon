/**
 * 
 */
package com.mindtree.TreeFelling.exception;


public class ServiceException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
