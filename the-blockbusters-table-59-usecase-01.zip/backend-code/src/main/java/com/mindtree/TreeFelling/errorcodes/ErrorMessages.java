/**
 * 
 */
package com.mindtree.TreeFelling.errorcodes;

public interface ErrorMessages {
	String Exception_IN_BLOCKCHAIN ="ERROR FROM BLOCKCHAIN";
    String Exeption_In_Database="Database not Connected";
    String Exception_Data_Not_Present="MISSING DATA";
    String Exception_IN_JSONPARSING = "JSON cannot be parsed";
}
