var express = require('express');
var builder = require('botbuilder');
var bodyParser = require('body-parser');


var server = express();
const LuisModelUrl = `https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/7151d96c-2b6e-4e39-aebe-27d399e010cf?subscription-key=${process.env.LUIS_SUBSCRIPTION_KEY}&verbose=true&timezoneOffset=0&q=`;

server.use(bodyParser.json());

var connector = new builder.ChatConnector({
    appId: process.env.MICROSOFT_APP_ID,
    appPassword: process.env.MICROSOFT_APP_PASSWORD
});

var bot = new builder.UniversalBot(connector);

var recognizer = new builder.LuisRecognizer(LuisModelUrl);
var intents = new builder.IntentDialog({ recognizers: [recognizer] });

intents
    .matches('status', (session) => {
        session.send("Your request is pending with RTO.");
    })
    .matches('getDocument', (session) => {
        session.send("Here is you requested docuement.");
    })
    .onDefault((session) => {
        session.send('Sorry, I don\'t have any idea about that. Please try asking me something about you application status.');
    });



bot.dialog('/', intents);

server.get('/', (req, res) => { res.send("<br>Blochy The Bot is servicing farmers' queries.") });
server.post('/api/messages', connector.listen());
server.post('/api/customMessages', (req, res) => {
    if (req.body.message) {
        var userId = process.env.BLOCHE_USER_ID_AJIT;
        var address = {
            channelId: "skype",
            user: { id: userId },
            bot: { id: process.env.BLOCHE_BOT_ID, name: "bloche" },
            serviceUrl: "https://smba.trafficmanager.net/apis/",
            useAuth: true,
        };
        var session = builder.Session({ library: '', dialogId: new Date() });
        var msg = new builder.Message()
            .address(address)
            .text(req.body.message);
        bot.send(msg, function(done) {
            console.log("Web hook msg sent");
            res.send("Message sent.");
        });
    } else {
        res.status(400).send("Message body not found");
    }
});
server.use('/public', express.static('public'));

server.listen(process.env.port || process.env.PORT || 3978, function() {
    console.log('%s listening to %s', server.name, server.url);
});