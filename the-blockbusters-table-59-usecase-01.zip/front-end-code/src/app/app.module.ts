import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import { ToasterModule } from 'angular2-toaster';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';

import { ROUTES } from './app.routes';
import { AppComponent } from './app.component';

// App views
import { LoginModule } from './views/login/login.module';
import {FarmerDashboardModule} from './views/farmerdashboard/farmerdashboard.module';
import { FarmerHomeModule } from './views/farmerhome/farmerhome.module';
import { ForestHomeModule } from "./views/foresthome/foresthome.module";
import { LandDetailsModule } from "./views/landdetails/landdetails.module";
import {PermitsDetailsModule  } from "./views/permitdetails/permitdetails.module";


// App modules/components
import { LayoutsModule } from './components/common/layouts/layouts.module';
import { LoggedInGuard } from './app.guard';

@NgModule({
  declarations: [AppComponent],
  imports: [
    // Angular modules
    BrowserModule,
    HttpModule,

    // Views
    LoginModule,
    FarmerDashboardModule,
    FarmerHomeModule,
    ForestHomeModule,
    LandDetailsModule,
    PermitsDetailsModule,
    ToasterModule,

    // DashboardModule,

    // Modules
    LayoutsModule,

    RouterModule.forRoot(ROUTES)
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    LoggedInGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
