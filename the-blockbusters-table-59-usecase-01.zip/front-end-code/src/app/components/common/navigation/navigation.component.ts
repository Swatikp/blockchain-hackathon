import {Component, OnInit, AfterViewInit} from '@angular/core';
import {Router} from '@angular/router';

declare var jQuery : any;

@Component({selector: 'navigation', templateUrl: 'navigation.template.html',styleUrls: ['navigation.style.css']})

export class NavigationComponent implements OnInit,AfterViewInit {
  userType: String;
  userName: String;
  constructor(private router : Router) {}

  ngAfterViewInit() {
    jQuery('#side-menu').metisMenu();
  }

  activeRoute(routename : string) : boolean {
    return this
      .router
      .url
      .indexOf(routename) > -1;
  }
  ngOnInit() {
    this.userType = sessionStorage.getItem("userType")
    this.userName = sessionStorage.getItem("userName")
    if(this.userType===null){
      this.userType='admin';
    }
  }

  logout() {
    sessionStorage.clear();
  }

}
