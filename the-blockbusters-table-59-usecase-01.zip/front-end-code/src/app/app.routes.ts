import {Routes} from "@angular/router";
import {loginComponent} from "./views/login/login.component";
import {blankComponent} from "./components/common/layouts/blank.component";
import {basicComponent} from "./components/common/layouts/basic.component";

import {FarmerDashboardComponent} from "./views/farmerdashboard/farmerdashboard.component";
import {FarmerHomeComponent} from "./views/farmerhome/farmerhome.component";
import {ForestHomeComponent} from "./views/foresthome/foresthome.component";
import {LandDetailsComponent} from "./views/landdetails/landdetails.component";

import {LoggedInGuard} from './app.guard';
import { InprogressPermitsForestHomeComponent } from "./views/foresthome/inprogresspermitsforestdept.component";
import { RejectedPermitsForestHomeComponent } from "./views/foresthome/rejectedpermitsforestdept.component";
import { ApprovedPermitsForestHomeComponent } from "./views/foresthome/approvedpermitsforestdept.component";
import { AllPermitsForestHomeComponent } from "./views/foresthome/allpermitsforestdept.component";
import { PermitsDetailsComponent } from "./views/permitdetails/permitdetails.component";

export const ROUTES : Routes = [
  // Main redirect
  {
    path: '',
    redirectTo: 'login/farmer',
    pathMatch: 'full'
  }, {
    path: '',
    component: basicComponent,
    children: [
      {
        path: 'farmerdashboard',
        component: FarmerDashboardComponent
      },
      {
        path: 'farmerhome',
        component: FarmerHomeComponent
      },
      {
        path: 'foresthome',
        redirectTo: 'permit/requested',
      },
      {
        path: 'permit/requested',
        component: InprogressPermitsForestHomeComponent
      },
      {
        path: 'permit/approved',
        component: ApprovedPermitsForestHomeComponent
      },
      {
        path: 'permit/rejected',
        component: RejectedPermitsForestHomeComponent
      },{
        path: 'permit/allpermits',
        component: AllPermitsForestHomeComponent
      },
      {
        path: 'permitDetails/:permitId',
        component: PermitsDetailsComponent
      }
      , {
        path: 'land/:landid',
        component: LandDetailsComponent
      }
    ]
  },
   {
    path: '',
    component: blankComponent,
    children: [
      {
        path: 'login/:id',
        component: loginComponent
      }, {
        path: '**',
        redirectTo: 'login'
      }
    ]
  }
];
