import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from './login.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';

@Component({
  styleUrls: ['login.style.css']
  , selector: 'login', templateUrl: 'login.template.html', providers: [LoginService]
})
export class loginComponent implements OnInit,
  AfterViewInit {

  user = {
    userId: '',
    password: ''
  };
  usertype;
  type: String;
  constructor(private route: ActivatedRoute, private router: Router, private loginService: LoginService, private toasterService: ToasterService) {
    this.route.params.subscribe(params => {
      console.log(params)
      this.usertype = params;
    });

  }

  onLogin() {
    console.log(this.usertype);
    // switch (this.usertype.id) {
    //   case "farmer":
    //     this.router.navigate(['/farmerdashboard']);
    //     break;
    //   case "forestdepartment":
    //   this.router.navigate(['/foresthome']);
    //     break;
    // }



    if (this.user.userId !== '' && this.user.password !== '') {
       this.loginService.login(this.user)
         .then(response => {
           var data=response;
           console.log(data)
          if (data.jwtToken && data.jwtToken!='') {
            sessionStorage.setItem('userName', data.userName);
            this.toasterService.pop("success", "Welcome "+data.userName, "");
            sessionStorage.setItem('jwtToken', data.jwtToken);
            sessionStorage.setItem('userId', data.userId);
            sessionStorage.setItem('phoneNo', data.phoneNo);
            sessionStorage.setItem('aadharNo', data.aadharNo);
            sessionStorage.setItem('address', data.address);
            sessionStorage.setItem('userType', data.userType.toLowerCase());
            if (data.userType.toLowerCase() === 'farmer') {
              this
                .router
                .navigate(['/farmerdashboard']);
            } else if (data.userType.toLowerCase() === 'forestdepartment') {
              this
                .router
                .navigate(['/foresthome']);
            } else {
                      this.toasterService.pop("error", "Please Enter valid credentials", "");
              }
          }
        }) .catch(err => { console.log('Error');
            this.toasterService.pop("error", "Please Enter valid credentials", "");
       });
      }
  }

  ngOnInit(): void {
    sessionStorage.clear();
  }
  ngAfterViewInit() {
    correctHeight();
    detectBody();
  }
}
