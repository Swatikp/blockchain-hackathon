import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

import { LandDetailsService } from './landdetails.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';
import { SweetAlertService } from 'angular-sweetalert-service';

@Component({

  styleUrls: ['landdetails.style.css'],
  selector: 'landdetails',
  templateUrl: './landdetails.template.html',
  providers: [LandDetailsService, DatePipe, { provide: 'Window', useValue: window }]
})

export class LandDetailsComponent  {
  constructor( @Inject('Window') private window: Window,private alertService: SweetAlertService, private datePipe: DatePipe, private landdetails: LandDetailsService, private router: Router, private route: ActivatedRoute, private toasterService: ToasterService
  ) { this.route.params.subscribe(params => {
    console.log(params)
    this.landid = params;
  }); }
  landid;
  userName;
  userId;
  aadharNo;
  address;
  phoneNo;
  userType;
  landinfo;
  trees;
  purpose;
  checkboxes;
  checkboxesChecked = [];
  nooftree;
land={
    landId:'',
    district:'',
    taluk:'',
    gps:'',
    totalExtent:'',
    landDocHash:''
    };;
  ngOnInit() {
    this.userName =  sessionStorage.getItem("userName")
    this.userId =   sessionStorage.getItem("userId")
    this.phoneNo =  sessionStorage.getItem("phoneNo")
    this.userType =  sessionStorage.getItem("userType")
    this.aadharNo =  sessionStorage.getItem("aadharNo")
    this.address =  sessionStorage.getItem("address")
    this.getLand();
    this.getTrees();
  }
  getLand(){
    var authorizeSP = document.getElementById("authorize-spinner");
    var spinner = document.getElementById("sk-spinner");
    authorizeSP.style["display"] = "block";
    spinner.style["display"] = "block";
    this.landdetails.getLand(this.landid)
    .then(response => {
      authorizeSP.style["display"] = "none";
    spinner.style["display"] = "none";
    this.land=response;
       console.log(response);
      this.landinfo = response;
    })
    .catch(response => {
      authorizeSP.style["display"] = "none";
    spinner.style["display"] = "none";
      console.log("fail", response);
    });
  }
  getTrees(){
    var authorizeSP = document.getElementById("authorize-spinner");
    var spinner = document.getElementById("sk-spinner");
    authorizeSP.style["display"] = "block";
    spinner.style["display"] = "block";
    this.landdetails.getTrees(this.landid)
    .then(response => {
      authorizeSP.style["display"] = "none";
    spinner.style["display"] = "none";
      this.trees = response;
      this.trees=this.trees.filter(tree=>{
        return tree.status!=='CUT'
      })
      this.checkboxes = document.getElementsByName("treecheckbox");
      console.log(this.checkboxes)
      // console.log("trees", this.trees);
    })
    .catch(response => {
      authorizeSP.style["display"] = "none";
    spinner.style["display"] = "none";
      console.log("fail", response);
    });
  }
  selectTree(id){


  if (this.checkboxesChecked.indexOf(id) === -1) {
    this.checkboxesChecked.push(id);
  }
  else {
    var index =  this.checkboxesChecked.indexOf(id);
    if (index > -1) {
      this.checkboxesChecked.splice(index, 1);
    }
  }

    // for (var i=0; i< this.checkboxes.length; i++) {
    //   if ((<HTMLInputElement>this.checkboxes[i]).checked) {
    //     console.log(this.checkboxes[i])
    //     this.checkboxesChecked.push((<HTMLInputElement>this.checkboxes[i]).value);
    //   }
    // }
    console.log(this.checkboxesChecked)
this.nooftree=this.checkboxesChecked.length;
  }
  onSubmit(){
    var statusID=[];
    this.checkboxesChecked.map((checkbox)=>{
      this.trees.map((tree)=>{
        if(tree.treeId===checkbox)
          statusID.push(tree.surveyNo)
      })
    })
    console.log(statusID)
    var permit={
      "bescomDocHash": "string",
      "createdOn": "string",
      "forestDocHash": "string",
      "grantedOn": "string",
      "landDocHash": this.land.landDocHash,
      "landId": this.landid.landid,
      "permitId": "string",
      "policeDocHash": "string",
      "purpose": this.purpose,
      "revenueDocHash": "string",
      "rtodocHash": "string",
      "sawMillDocHash": "string",
      "status": "string",
      "surveyDocHash": "string",
      "surveyNo": statusID,
      "treeId": this.checkboxesChecked,
      "userId": this.userId   }
      this.landdetails.addPermit(permit)
      .then(response=>{
        this.alertService.info({
          title: 'Permit Requested Successfully'
        }).then(() => {
          this
          .router
          .navigate(['/foresthome']);
        })
      }).catch(response=>{

        console.log(response)
      })
    console.log(permit)
  }

}
