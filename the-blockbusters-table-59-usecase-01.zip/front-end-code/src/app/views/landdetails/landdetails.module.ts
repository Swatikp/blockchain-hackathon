import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { LandDetailsComponent } from "./landdetails.component";
import { RouterModule } from "@angular/router";
import { FormsModule } from '@angular/forms';
import { SweetAlertService } from 'angular-sweetalert-service';
@NgModule({
  declarations: [LandDetailsComponent],
  imports: [BrowserModule, RouterModule, FormsModule],
  providers:[SweetAlertService]
})

export class LandDetailsModule { }
