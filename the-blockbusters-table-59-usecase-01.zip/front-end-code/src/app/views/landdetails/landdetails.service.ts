import { Injectable } from '@angular/core';
import { Headers, Http,RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../../environments/environment';

@Injectable()
export class LandDetailsService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  private Url = environment.API_URL + 'api/';
  constructor(private http: Http) { }

  getLand(id): Promise<any> {

    let header=new Headers({'Content-Type': 'application/json',
     'Authorization':
  sessionStorage.getItem("jwtToken")});
  let options = new RequestOptions({ headers: header });
  return this.http.get(this.Url + 'lands/'+id.landid,options)
    .toPromise()
    .then(response => response.json())
    .catch(this.handleError);
}

getTrees(id): Promise<any> {

  let header=new Headers({'Content-Type': 'application/json',
   'Authorization':
sessionStorage.getItem("jwtToken")});
let options = new RequestOptions({ headers: header });
return this.http.get(this.Url + 'lands/'+id.landid+'/trees',options)
  .toPromise()
  .then(response => response.json())
  .catch(this.handleError);
}


addPermit(permit): Promise<any> {
  let header=new Headers({'Content-Type': 'application/json',
  'Authorization':
sessionStorage.getItem("jwtToken")});
let options = new RequestOptions({ headers: header });
  return this.http
    .post(this.Url+'treePermits',permit, options)
    .toPromise()
    .then(response => response)
    .catch(this.handleError);
}

  private handleError(error: any): Promise<any> {
    return Promise.reject(error.message || error);
  }
}
