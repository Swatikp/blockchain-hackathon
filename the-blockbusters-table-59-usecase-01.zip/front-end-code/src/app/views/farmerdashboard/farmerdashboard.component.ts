import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

import { FarmerDashboardService } from './farmerdashboard.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';


@Component({

  styleUrls: ['farmerdashboard.style.css'],
  selector: 'farmerdashboard',
  templateUrl: './farmerdashboard.template.html',
  providers: [FarmerDashboardService, DatePipe, { provide: 'Window', useValue: window }]
})

export class FarmerDashboardComponent  {
  constructor( @Inject('Window') private window: Window, private datePipe: DatePipe, private farmerdashboard: FarmerDashboardService, private router: Router, private route: ActivatedRoute, private toasterService: ToasterService
  ) {
    this.route.params.subscribe(params => {
      console.log(params)
      // this.permitView = params;
    });
   }


}
