import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FarmerDashboardComponent } from "./farmerdashboard.component";
import { RouterModule } from "@angular/router";
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [FarmerDashboardComponent],
  imports: [BrowserModule, RouterModule, FormsModule]
})

export class FarmerDashboardModule { }
