import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

import {PermitDetailsService  } from './permitdetails.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';
import { SweetAlertService } from 'angular-sweetalert-service';
import { environment } from '../../../environments/environment';

@Component({

  styleUrls: ['permitDetails.style.css'],
  selector: 'permitDetails',
  templateUrl: './permitdetails.template.html',
  providers: [PermitDetailsService, DatePipe, { provide: 'Window', useValue: window }]
})

export class PermitsDetailsComponent  implements OnInit{
  pdfUrl = environment.pdf;
  permitId:String;
  permit = {
    treeId:[],
    surveyNo:[],
    permitId:"",
    landId:"",
    grantedOn:'',
    createdOn:'',
    status:'',
    landDocHash:'',
    purpose:''
  }
  trees=[];
  constructor( @Inject('Window') private window: Window, private alertService: SweetAlertService,private datePipe: DatePipe, private permitDetailsService: PermitDetailsService, private router: Router, private route: ActivatedRoute, private toasterService: ToasterService
  ) {
    this.route.params.subscribe(params => {
      this.permitId = params.permitId;
    });
  }

  ngOnInit(): void {
    var authorizeSP = document.getElementById("authorize-spinner");
    var spinner = document.getElementById("sk-spinner");
    authorizeSP.style["display"] = "block";
    spinner.style["display"] = "block";
   this.permitDetailsService.getPermit(this.permitId).then(permit=>{
    authorizeSP.style["display"] = "none";
    spinner.style["display"] = "none";
    this.permit = permit;
    this.permit.createdOn=new Date(parseInt(this.permit.createdOn)).toDateString();
    console.log(this.permit)
    this.permit.treeId.map(tree=>{
      this.permitDetailsService.getTrees(this.permit.landId).then(allTrees=>{
       this.trees.push( allTrees.filter(currentTree=>{
          return currentTree.treeId===tree
        })[0])
        console.log(this.trees)
      })
    })
   })
   .catch(response=>{
    authorizeSP.style["display"] = "none";
    spinner.style["display"] = "none";
     console.log(response);
   })
  }

  approve(){
    var authorizeSP = document.getElementById("authorize-spinner");
    var spinner = document.getElementById("sk-spinner");
    authorizeSP.style["display"] = "block";
    spinner.style["display"] = "block";
    this.permitDetailsService.changePermitStatus('grant',this.permit.permitId).then(response=>{
      authorizeSP.style["display"] = "none";
      spinner.style["display"] = "none";
      this.permit.status='GRANTED';
      this.alertService.success({
        title: 'Request Granted'
      })
    })
    .catch(response=>{
      authorizeSP.style["display"] = "none";
      spinner.style["display"] = "none";
      console.log(response)
    })
  }
  reject(){
    var authorizeSP = document.getElementById("authorize-spinner");
    var spinner = document.getElementById("sk-spinner");
    authorizeSP.style["display"] = "block";
    spinner.style["display"] = "block";
    this.permitDetailsService.changePermitStatus('reject',this.permit.permitId).then(response=>{
      authorizeSP.style["display"] = "none";
      spinner.style["display"] = "none";
      this.permit.status='REJECTED';
      this.alertService.success({
        title: 'Request Rejected'
      })
    })
    .catch(response=>{
      authorizeSP.style["display"] = "none";
      spinner.style["display"] = "none";
      console.log(response)
    })
  }

}
