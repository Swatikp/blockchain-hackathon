import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';



@Component({
  styleUrls: ['requestprogress.style.css'],
  selector: 'requestprogress',
  templateUrl: './requestprogress.template.html'
})

export class RequestProgressComponent  {
  permitId:String;
  constructor(
  ) { 

  }


}
