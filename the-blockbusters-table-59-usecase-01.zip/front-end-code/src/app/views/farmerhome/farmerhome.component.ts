import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from '@angular/common';

import { FarmerHomeService } from './farmerhome.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';
const jsPDF = require('jspdf');
require('jspdf-autotable');
declare var $: any;

@Component({

  styleUrls: ['farmerhome.style.css'],
  selector: 'farmerhome',
  templateUrl: './farmerhome.template.html',
  providers: [FarmerHomeService, DatePipe, { provide: 'Window', useValue: window }]
})

export class FarmerHomeComponent implements OnInit, AfterViewInit {
  constructor( @Inject('Window') private window: Window, private datePipe: DatePipe, private farmerhomeservice: FarmerHomeService, private router: Router, private route: ActivatedRoute, private toasterService: ToasterService
  ) { }


  ngAfterViewInit() {
    correctHeight();
    detectBody();

  }
  navigationUrl;
  jwtToken;
  lands;
  ngOnInit() {
    this.lands = [];
    this.getLands();
  }
  getLands() {
    var authorizeSP = document.getElementById("authorize-spinner");
    var spinner = document.getElementById("sk-spinner");
    authorizeSP.style["display"] = "block";
    spinner.style["display"] = "block";
    this.farmerhomeservice.getLands()
      .then(response => {
        authorizeSP.style["display"] = "none";
      spinner.style["display"] = "none";
        console.log(response);
        this.lands = response;
      })
      .catch(response => {
        authorizeSP.style["display"] = "none";
      spinner.style["display"] = "none";
        console.log("fail", response);
      });
  }
  getLandDetails(landid){
    console.log(landid);
    this.navigationUrl = "land/" +landid;
    console.log(this.navigationUrl);
    this.router.navigate([this.navigationUrl]);
  }

}
