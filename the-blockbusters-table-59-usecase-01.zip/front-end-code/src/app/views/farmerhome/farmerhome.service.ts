import { Injectable } from '@angular/core';
import { Headers, Http,RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../../environments/environment';

@Injectable()
export class FarmerHomeService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  private Url = environment.API_URL + 'api/';
  constructor(private http: Http) { }


  getLands(): Promise<any> {

      let header=new Headers({'Content-Type': 'application/json',
       'Authorization':
    sessionStorage.getItem("jwtToken")});
    let options = new RequestOptions({ headers: header });
    console.log("options",options)
    return this.http.get(this.Url + 'users/lands',options)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    return Promise.reject(error.message || error);
  }
}
