import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FarmerHomeComponent } from "./farmerhome.component";
import { RouterModule } from "@angular/router";
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [FarmerHomeComponent],
  imports: [BrowserModule, RouterModule, FormsModule]
})

export class FarmerHomeModule { }
