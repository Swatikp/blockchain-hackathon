import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DatePipe } from '@angular/common';

import { ForestHomeService } from './foresthome.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';


@Component({

  styleUrls: ['foresthome.style.css'],
  selector: 'foresthome',
  templateUrl: './foresthome.template.html',
  providers: [ForestHomeService, DatePipe, { provide: 'Window', useValue: window }]
})

export class ForestHomeComponent{
  permitView: Params;
  title: String;
  constructor( @Inject('Window') private window: Window, private datePipe: DatePipe, private foresthome: ForestHomeService, private router: Router, private route: ActivatedRoute, private toasterService: ToasterService
  ) {
    this.route.params.subscribe(params => {
      this.permitView = params;
    });
  }
}
