import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DatePipe } from '@angular/common';

import { ForestHomeService } from './foresthome.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';


@Component({
  styleUrls: ['foresthome.style.css'],
  selector: 'foresthome',
  templateUrl: './foresthome.template.html',
  providers: [ForestHomeService, DatePipe, { provide: 'Window', useValue: window }]
})

export class InprogressPermitsForestHomeComponent{
  title: String;
  navigationUrl:String;
  permits:any;
  constructor( @Inject('Window') private window: Window, private forestHomeService: ForestHomeService, private datePipe: DatePipe, private foresthome: ForestHomeService, private router: Router, private route: ActivatedRoute, private toasterService: ToasterService
  ) {

  this.title = "Requested Permits";
  }
  permitDetails(permitId){
    console.log(permitId)
      this.navigationUrl = `/permitDetails/${permitId}`;
      this.router.navigate([this.navigationUrl]);
  }
  ngOnInit(): void {
    this.permits = [];
    var authorizeSP = document.getElementById("authorize-spinner");
    var spinner = document.getElementById("sk-spinner");
    authorizeSP.style["display"] = "block";
    spinner.style["display"] = "block";
    this.forestHomeService.getAllPermits()
      .then(response => {
        authorizeSP.style["display"] = "none";
        spinner.style["display"] = "none";
        console.log(response);
        this.permits = response.filter(permit=>{
          return permit.status === 'REQUESTED';
        });
        this.permits.map(permit=>{
          permit.createdOn=new Date(parseInt(permit.createdOn)).toDateString()
        })
      })
      .catch(response => {
        authorizeSP.style["display"] = "none";
        spinner.style["display"] = "none";
        console.log("fail", response);
      });
  }
}
