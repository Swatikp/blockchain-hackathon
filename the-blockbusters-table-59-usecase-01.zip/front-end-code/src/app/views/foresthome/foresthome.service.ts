import { Injectable } from '@angular/core';
import { Headers, Http,RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { environment } from '../../../environments/environment';

@Injectable()
export class ForestHomeService {
  private headers = new Headers({ 'Content-Type': 'application/json' });
  private Url = environment.API_URL + 'api/';
  constructor(private http: Http) { }


  getAllPermits(): Promise<any> {
      // let header=new Headers({'Content-Type': 'application/json',
      //  'Authorization':
      //  "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhaml0LnNpbmdoQGdtYWlsLmNvbSIsInJvbGVzIjoidXNlciIsImlhdCI6MTUxNjQ3NTU2M30.E5VX-4fjaCswxW7bGcHmJplDyc1HoIiEqJl23loa2Sc"});
       let header=new Headers({'Content-Type': 'application/json',
       'Authorization':
      sessionStorage.getItem('jwtToken')});
    let options = new RequestOptions({ headers: header });
    console.log("options",options)
    return this.http.get(this.Url + 'permits',options)
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError);
  };
  private handleError(error: any): any {
    // console.log(error);

    return Promise.reject(error.message || error);
  }
}
