import { Component, OnInit, AfterViewInit, Inject } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { DatePipe } from '@angular/common';

import { ForestHomeService } from './foresthome.service';
import { correctHeight, detectBody } from '../../app.helpers';
import { ToasterService } from 'angular2-toaster';


@Component({

  styleUrls: ['foresthome.style.css'],
  selector: 'foresthome',
  templateUrl: './foresthome.template.html',
  providers: [ForestHomeService, DatePipe, { provide: 'Window', useValue: window }]
})

export class RejectedPermitsForestHomeComponent{
  title: String;
  navigationUrl:String;
  permits:any;
  constructor( @Inject('Window') private window: Window, private datePipe: DatePipe, private forestHomeService: ForestHomeService, private router: Router, private route: ActivatedRoute, private toasterService: ToasterService
  ) {
    this.title = "Rejected Permits";
  }
  permitDetails(permitId){
    console.log(permitId)
      this.navigationUrl = `/permitDetails/${permitId}`;
      this.router.navigate([this.navigationUrl]);
  }

  ngOnInit(): void {
    this.permits = [];
    this.forestHomeService.getAllPermits()
      .then(response => {
        console.log(response);
        this.permits = response.filter(permit=>{
          return permit.status === 'REJECTED';
        });
        this.permits.map(permit=>{
          permit.createdOn=new Date(parseInt(permit.createdOn)).toDateString()
        })
      })
      .catch(response => {
        console.log("fail", response);
      });
  }
}
