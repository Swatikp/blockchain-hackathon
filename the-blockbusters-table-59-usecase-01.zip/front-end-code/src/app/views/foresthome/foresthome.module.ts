import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { ForestHomeComponent } from "./foresthome.component";
import { InprogressPermitsForestHomeComponent } from "./inprogresspermitsforestdept.component";
import { ApprovedPermitsForestHomeComponent } from "./approvedpermitsforestdept.component";
import { RejectedPermitsForestHomeComponent } from "./rejectedpermitsforestdept.component";
import { AllPermitsForestHomeComponent } from "./allpermitsforestdept.component";
import { RouterModule } from "@angular/router";
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [ForestHomeComponent,InprogressPermitsForestHomeComponent,ApprovedPermitsForestHomeComponent
  ,RejectedPermitsForestHomeComponent,AllPermitsForestHomeComponent],
  imports: [BrowserModule, RouterModule, FormsModule]
})

export class ForestHomeModule { }
