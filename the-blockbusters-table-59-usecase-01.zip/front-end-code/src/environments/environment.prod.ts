export const environment = {
  production: true,
  API_URL: 'http://hyperv1.westus2.cloudapp.azure.com:51032/'
};
